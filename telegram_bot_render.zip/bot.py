from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

TOKEN = "8390471387:AAFkFWzAESxC8xLkLafl9ojAUP8QJHBDoas"

def start(update: Update, context: CallbackContext):
    update.message.reply_text("سلام! من ربات تو هستم 🤖")

def echo(update: Update, context: CallbackContext):
    update.message.reply_text(f"تو گفتی: {update.message.text}")

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, echo))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
